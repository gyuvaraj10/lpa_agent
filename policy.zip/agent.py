"""Intake agent built with LangChain's create_agent (LangChain 1.x).

build_intake_agent() -> compiled agent returning an IntakeResult as structured output.
run_intake()         -> runs one case, captures the tool-call trace, and compares the
                        agent's answer with the deterministic ground truth.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from langchain.agents import create_agent
from langchain.chat_models import init_chat_model
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage

from prompts import INTAKE_SYSTEM_PROMPT
from schemas import IntakeResult
from tools import build_tools, inspect_case

DEFAULT_MODEL = "anthropic:claude-sonnet-5-5"  # override with INTAKE_MODEL or the model argument
PASSTHROUGH_FIELDS = [
    "application_id", "applicant_id", "applicant_name", "employer",
    "loan_purpose", "loan_amount", "term_months", "stated_monthly_income",
]


def build_intake_agent(data_dir: str | Path, model: str | BaseChatModel | None = None,
                       scan_for_injection: bool = True):
    if model is None or isinstance(model, str):
        # temperature=0 for repeatability. If your model rejects the parameter, drop it.
        model = init_chat_model(model or os.getenv("INTAKE_MODEL", DEFAULT_MODEL), temperature=0)
    return create_agent(
        model,
        tools=build_tools(data_dir, scan_for_injection),
        system_prompt=INTAKE_SYSTEM_PROMPT,
        response_format=IntakeResult,
    )


@dataclass
class IntakeRun:
    case_id: str
    result: IntakeResult           # final answer after reconciliation
    agent_output: IntakeResult     # what the agent actually produced
    reconciled: bool               # True if the agent's output had to be corrected
    corrections: list[str] = field(default_factory=list)
    tool_calls: list[dict] = field(default_factory=list)


def extract_tool_calls(messages) -> list[dict]:
    """Tool calls in order, excluding the structured-output call itself."""
    calls = []
    for m in messages:
        if isinstance(m, AIMessage):
            for c in m.tool_calls:
                if c["name"] != IntakeResult.__name__:
                    calls.append({"name": c["name"], "args": c["args"]})
    return calls


def reconcile(raw: IntakeResult, truth: dict) -> tuple[IntakeResult, list[str]]:
    """Deterministic guardrail: correct anything the agent got wrong versus the tools' facts."""
    fixes: dict = {}
    notes: list[str] = []
    v = truth["validation"]

    if raw.status != truth["expected_status"]:
        fixes["status"] = truth["expected_status"]
        notes.append("status")
    if set(raw.missing_fields) != set(v["missing_fields"]):
        fixes["missing_fields"] = v["missing_fields"]
        notes.append("missing_fields")
    if {i.field for i in raw.invalid_fields} != {i["field"] for i in v["invalid_fields"]}:
        fixes["invalid_fields"] = v["invalid_fields"]
        notes.append("invalid_fields")
    if set(raw.missing_documents) != set(truth["missing_documents"]):
        fixes["missing_documents"] = truth["missing_documents"]
        notes.append("missing_documents")

    app = truth["application"] or {}
    for f in PASSTHROUGH_FIELDS:
        expected = app.get(f)
        if getattr(raw, f) != expected:
            fixes[f] = expected
            notes.append(f)

    if any(d["possible_embedded_instructions"] for d in truth["documents"]) and not raw.document_warnings:
        fixes["document_warnings"] = ["document contains instruction-like text (flagged by deterministic scan)"]
        notes.append("document_warnings")

    if not fixes:
        return raw, []
    fixed = raw.model_copy(update=fixes)
    fixed.notes = (raw.notes + " [Corrected by deterministic check: " + ", ".join(notes) + "]").strip()
    return fixed, notes


def run_intake(case_id: str, agent, data_dir: str | Path, scan_for_injection: bool = True) -> IntakeRun:
    out = agent.invoke(
        {"messages": [{"role": "user", "content": f"Process intake for case_id={case_id}"}]},
        config={"recursion_limit": 20},
    )
    raw: IntakeResult = out["structured_response"]
    truth = inspect_case(case_id, Path(data_dir), scan_for_injection)
    final, corrections = reconcile(raw, truth)
    return IntakeRun(
        case_id=case_id,
        result=final,
        agent_output=raw,
        reconciled=bool(corrections),
        corrections=corrections,
        tool_calls=extract_tool_calls(out["messages"]),
    )
