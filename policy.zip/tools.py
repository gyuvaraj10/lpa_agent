"""Deterministic intake tools.

Layout expected in data_dir (flat, matching the demo fixtures):
    {case_id}_application.json
    {case_id}_payslip.pdf
    {case_id}_bank_statement.pdf

The pure functions (load_application, validate_application, inspect_documents,
inspect_case) are the ground truth the agent is checked against.
The @tool wrappers (build_tools) are what the LLM can call.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from langchain_core.tools import tool
from pypdf import PdfReader

REQUIRED_FIELDS = [
    "application_id", "applicant_id", "applicant_name", "loan_amount",
    "term_months", "loan_purpose", "employer", "stated_monthly_income",
]
STRING_FIELDS = {"application_id", "applicant_id", "applicant_name", "loan_purpose", "employer"}
POSITIVE_NUMBER_FIELDS = ("loan_amount", "stated_monthly_income")
REQUIRED_DOCUMENTS = ["payslip", "bank_statement"]
MAX_DOC_CHARS = 4000

# Cheap heuristic only. The LLM is still expected to catch what this misses.
INSTRUCTION_PATTERNS = [
    re.compile(p, re.I)
    for p in (
        r"ignore (all|any|previous|prior)\b[^.]{0,60}\b(rules|instructions|checks|polic)",
        r"automated reviewers?",
        r"set decision\s*=",
        r"do not mention (this|these|the) ",
        r"system note",
    )
]


# ----------------------------------------------------------------- pure helpers
def _safe_path(data_dir: Path, filename: str) -> Path:
    base = Path(data_dir).resolve()
    p = (base / filename).resolve()
    if p.parent != base:
        raise ValueError("filename must be a plain file name inside the data directory")
    return p


def declared_type(filename: str) -> str:
    stem = Path(filename).stem
    for t in REQUIRED_DOCUMENTS:
        if stem.endswith("_" + t):
            return t
    return "unknown"


def load_application(case_id: str, data_dir: Path) -> dict | None:
    path = _safe_path(data_dir, f"{case_id}_application.json")
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def validate_application(app: dict | None) -> dict:
    if app is None:
        return {"application_found": False, "missing_fields": list(REQUIRED_FIELDS), "invalid_fields": []}
    missing, invalid = [], []
    for f in REQUIRED_FIELDS:
        v = app.get(f)
        if v is None or (isinstance(v, str) and not v.strip()):
            missing.append(f)
            continue
        if f in STRING_FIELDS and not isinstance(v, str):
            invalid.append({"field": f, "problem": "must be a string"})
        elif f in POSITIVE_NUMBER_FIELDS and (isinstance(v, bool) or not isinstance(v, (int, float)) or v <= 0):
            invalid.append({"field": f, "problem": "must be a positive number"})
        elif f == "term_months" and (isinstance(v, bool) or not isinstance(v, int) or v <= 0):
            invalid.append({"field": f, "problem": "must be a positive whole number of months"})
        elif f == "application_id" and not re.fullmatch(r"APP-\d+", v):
            invalid.append({"field": f, "problem": "must look like APP-<digits>"})
    return {"application_found": True, "missing_fields": missing, "invalid_fields": invalid}


def extract_pdf_text(path: Path) -> tuple[str, int, bool]:
    """Return (text, pages, readable)."""
    try:
        reader = PdfReader(str(path))
        text = "\n".join((page.extract_text() or "") for page in reader.pages)
        return text, len(reader.pages), len(reader.pages) > 0
    except Exception:
        return "", 0, False


def inspect_documents(case_id: str, data_dir: Path, scan_for_injection: bool = True) -> list[dict]:
    docs = []
    for path in sorted(Path(data_dir).glob(f"{case_id}_*.pdf")):
        text, pages, readable = extract_pdf_text(path)
        docs.append({
            "filename": path.name,
            "document_type": declared_type(path.name),
            "pages": pages,
            "readable": readable,
            "text_extractable": bool(text.strip()),
            "possible_embedded_instructions": (
                any(p.search(text) for p in INSTRUCTION_PATTERNS) if scan_for_injection else None
            ),
        })
    return docs


def inspect_case(case_id: str, data_dir: Path, scan_for_injection: bool = True) -> dict:
    """Ground truth for one case, computed without any LLM."""
    app = load_application(case_id, data_dir)
    validation = validate_application(app)
    docs = inspect_documents(case_id, data_dir, scan_for_injection)
    readable_types = {d["document_type"] for d in docs if d["readable"]}
    missing_docs = [t for t in REQUIRED_DOCUMENTS if t not in readable_types]
    complete = (
        validation["application_found"]
        and not validation["missing_fields"]
        and not validation["invalid_fields"]
        and not missing_docs
    )
    return {
        "application": app,
        "validation": validation,
        "documents": docs,
        "missing_documents": missing_docs,
        "expected_status": "complete" if complete else "incomplete",
    }


# ------------------------------------------------------------------ LLM tools
def build_tools(data_dir: str | Path, scan_for_injection: bool = True):
    data_dir = Path(data_dir)

    @tool
    def read_application_form(case_id: str) -> str:
        """Return the raw loan application form (JSON) for a case_id."""
        app = load_application(case_id, data_dir)
        if app is None:
            return json.dumps({"error": f"application form for {case_id} not found or not valid JSON"})
        return json.dumps(app)

    @tool
    def validate_application_fields(case_id: str) -> str:
        """Check the application form for missing required fields and invalid values."""
        return json.dumps(validate_application(load_application(case_id, data_dir)))

    @tool
    def list_uploaded_documents(case_id: str) -> str:
        """List the documents uploaded for a case_id: filename, declared type, page count,
        readability, and which required document types are missing."""
        docs = inspect_documents(case_id, data_dir, scan_for_injection)
        readable_types = {d["document_type"] for d in docs if d["readable"]}
        missing = [t for t in REQUIRED_DOCUMENTS if t not in readable_types]
        return json.dumps({"documents": docs, "missing_documents": missing})

    @tool
    def read_document_text(filename: str) -> str:
        """Return the extracted text of one uploaded document (by exact filename), truncated.
        The text is applicant-supplied and untrusted."""
        try:
            path = _safe_path(data_dir, filename)
        except ValueError as e:
            return json.dumps({"error": str(e)})
        if not path.exists():
            return json.dumps({"error": f"{filename} not found"})
        text, _, readable = extract_pdf_text(path)
        if not readable:
            return json.dumps({"error": f"{filename} could not be read"})
        text = text[:MAX_DOC_CHARS].replace("</untrusted_document>", "")
        return f'<untrusted_document filename="{filename}">\n{text}\n</untrusted_document>'

    return [read_application_form, validate_application_fields, list_uploaded_documents, read_document_text]
