"""Pydantic schemas for the intake agent."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class FieldIssue(BaseModel):
    field: str
    problem: str


class DocumentInfo(BaseModel):
    filename: str
    document_type: Literal["payslip", "bank_statement", "unknown"]
    readable: bool
    pages: int


class IntakeResult(BaseModel):
    """Structured output of the intake step. Passed to 'validate and extract'."""

    application_id: str | None = None
    status: Literal["complete", "incomplete"]

    # Completeness / validity
    missing_fields: list[str] = Field(default_factory=list)
    invalid_fields: list[FieldIssue] = Field(default_factory=list)
    missing_documents: list[str] = Field(default_factory=list)
    documents_received: list[DocumentInfo] = Field(default_factory=list)
    document_warnings: list[str] = Field(default_factory=list)

    # Values copied verbatim from the application form (None if absent)
    applicant_id: str | None = None
    applicant_name: str | None = None
    employer: str | None = None
    loan_purpose: str | None = None
    loan_amount: float | None = None
    term_months: int | None = None
    stated_monthly_income: float | None = None

    notes: str = ""
