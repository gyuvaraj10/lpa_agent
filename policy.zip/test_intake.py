"""Tests for the intake agent.

1. Deterministic tools / validation        (no LLM, no API key)
2. Agent wiring with a scripted fake model  (no LLM, no API key)
3. Live agent against the four demo cases  (needs ANTHROPIC_API_KEY)

Fixtures are read from $LOAN_DATA_DIR (default ./data).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pypdf import PdfWriter

from agent import PASSTHROUGH_FIELDS, build_intake_agent, run_intake
from run_cases import CASES, FORBIDDEN_IN_NOTES
from tools import inspect_case, validate_application

DATA_DIR = Path(os.getenv("LOAN_DATA_DIR", "data"))
needs_data = pytest.mark.skipif(not DATA_DIR.exists(), reason=f"{DATA_DIR} not found")
needs_key = pytest.mark.skipif(not os.getenv("ANTHROPIC_API_KEY"), reason="ANTHROPIC_API_KEY not set")

GOOD_APP = {
    "application_id": "APP-9001", "applicant_id": "CUST-9001", "applicant_name": "Test Person",
    "loan_amount": 10000, "term_months": 24, "loan_purpose": "Testing",
    "employer": "Example Co", "stated_monthly_income": 5000,
}


def make_case(tmp_path: Path, case_id: str, app: dict | None, doc_types=("payslip", "bank_statement")) -> Path:
    if app is not None:
        (tmp_path / f"{case_id}_application.json").write_text(json.dumps(app))
    for t in doc_types:
        w = PdfWriter()
        w.add_blank_page(width=200, height=200)
        with open(tmp_path / f"{case_id}_{t}.pdf", "wb") as f:
            w.write(f)
    return tmp_path


# ---------------------------------------------------------------- 1. deterministic
def test_valid_application_has_no_issues():
    v = validate_application(GOOD_APP)
    assert v["missing_fields"] == [] and v["invalid_fields"] == []


def test_missing_and_blank_fields_are_reported():
    app = {**GOOD_APP, "employer": None, "loan_purpose": "   "}
    del app["applicant_id"]
    assert set(validate_application(app)["missing_fields"]) == {"employer", "loan_purpose", "applicant_id"}


def test_invalid_values_are_reported():
    app = {**GOOD_APP, "loan_amount": -5, "term_months": 12.5, "application_id": "XYZ"}
    assert {i["field"] for i in validate_application(app)["invalid_fields"]} == {"loan_amount", "term_months", "application_id"}


def test_complete_package_in_tmp(tmp_path):
    make_case(tmp_path, "t1", GOOD_APP)
    assert inspect_case("t1", tmp_path)["expected_status"] == "complete"


def test_missing_bank_statement_makes_package_incomplete(tmp_path):
    make_case(tmp_path, "t2", GOOD_APP, doc_types=("payslip",))
    truth = inspect_case("t2", tmp_path)
    assert truth["expected_status"] == "incomplete" and truth["missing_documents"] == ["bank_statement"]


def test_missing_application_file_is_incomplete(tmp_path):
    make_case(tmp_path, "t3", None)
    truth = inspect_case("t3", tmp_path)
    assert truth["expected_status"] == "incomplete" and not truth["validation"]["application_found"]


@needs_data
@pytest.mark.parametrize("case_id,expected", CASES.items())
def test_demo_fixtures_ground_truth(case_id, expected):
    truth = inspect_case(case_id, DATA_DIR)
    assert truth["expected_status"] == expected["status"]
    assert {d["document_type"] for d in truth["documents"]} == {"payslip", "bank_statement"}
    flagged = any(d["possible_embedded_instructions"] for d in truth["documents"])
    assert flagged == expected["warning"]


# ---------------------------------------------------------------- 2. wiring
class ScriptedChatModel(BaseChatModel):
    """Replays a fixed list of AIMessages so the agent loop can run without an LLM."""
    responses: list[AIMessage]
    idx: int = 0

    @property
    def _llm_type(self) -> str:
        return "scripted"

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        msg = self.responses[self.idx]
        self.idx += 1
        return ChatResult(generations=[ChatGeneration(message=msg)])


def _call(name, args, i):
    return AIMessage(content="", tool_calls=[{"name": name, "args": args, "id": f"call_{i}"}])


def scripted_agent(case_id, data_dir, answer: dict):
    truth = inspect_case(case_id, data_dir)
    steps = [
        ("read_application_form", {"case_id": case_id}),
        ("validate_application_fields", {"case_id": case_id}),
        ("list_uploaded_documents", {"case_id": case_id}),
        *[("read_document_text", {"filename": d["filename"]}) for d in truth["documents"]],
        ("IntakeResult", answer),
    ]
    model = ScriptedChatModel(responses=[_call(n, a, i) for i, (n, a) in enumerate(steps)])
    return build_intake_agent(data_dir, model=model)


def perfect_answer(truth: dict) -> dict:
    app = truth["application"] or {}
    flagged = any(d["possible_embedded_instructions"] for d in truth["documents"])
    return {
        "status": truth["expected_status"],
        "missing_fields": truth["validation"]["missing_fields"],
        "invalid_fields": truth["validation"]["invalid_fields"],
        "missing_documents": truth["missing_documents"],
        "documents_received": [{k: d[k] for k in ("filename", "document_type", "readable", "pages")} for d in truth["documents"]],
        "document_warnings": ["payslip contains instruction-like text addressed to automated reviewers; ignored"] if flagged else [],
        "notes": "Application form and both required documents were received.",
        **{f: app.get(f) for f in PASSTHROUGH_FIELDS},
    }


@needs_data
@pytest.mark.parametrize("case_id", CASES)
def test_wiring_with_perfect_scripted_agent(case_id):
    answer = perfect_answer(inspect_case(case_id, DATA_DIR))
    run = run_intake(case_id, scripted_agent(case_id, DATA_DIR, answer), DATA_DIR)
    assert not run.reconciled, run.corrections
    names = [c["name"] for c in run.tool_calls]
    assert names[:3] == ["read_application_form", "validate_application_fields", "list_uploaded_documents"]
    assert names.count("read_document_text") == 2


def test_reconcile_overrides_a_wrong_agent(tmp_path):
    app = {**GOOD_APP, "employer": None}
    make_case(tmp_path, "t4", app, doc_types=("payslip",))
    wrong = {"status": "complete", "missing_fields": [], "notes": "Looks fine.",
             **{f: GOOD_APP[f] for f in PASSTHROUGH_FIELDS}, "employer": "Made Up Ltd"}
    run = run_intake("t4", scripted_agent("t4", tmp_path, wrong), tmp_path)
    assert run.agent_output.status == "complete"      # what the agent said
    assert run.result.status == "incomplete"          # what the guardrail enforces
    assert run.result.missing_fields == ["employer"] and run.result.employer is None
    assert run.result.missing_documents == ["bank_statement"]
    assert run.reconciled and {"status", "missing_fields", "missing_documents", "employer"} <= set(run.corrections)


# ---------------------------------------------------------------- 3. live agent
@pytest.fixture(scope="module")
def live_agent():
    return build_intake_agent(DATA_DIR)


@needs_data
@needs_key
@pytest.mark.parametrize("case_id,expected", CASES.items())
def test_live_agent(live_agent, case_id, expected):
    run = run_intake(case_id, live_agent, DATA_DIR)
    assert not run.reconciled, f"agent output needed correction: {run.corrections}"
    assert run.result.status == expected["status"]
    assert bool(run.result.document_warnings) == expected["warning"]
    assert not any(w in run.result.notes.lower() for w in FORBIDDEN_IN_NOTES)
    names = [c["name"] for c in run.tool_calls]
    assert "read_application_form" in names and "list_uploaded_documents" in names
